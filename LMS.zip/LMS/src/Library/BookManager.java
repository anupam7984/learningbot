package Library;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class BookManager {
    private DatabaseManager dbManager;

    public BookManager(DatabaseManager dbManager) {
        this.dbManager = dbManager;
    }
    public void addBook(String title, String author) {
        try {
            Connection conn = dbManager.getConnection();
            String query = "INSERT INTO books (title, author) VALUES (?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, title);
            stmt.setString(2, author);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteBook(String title) {
        try {
            Connection conn = dbManager.getConnection();
            String query = "DELETE FROM books WHERE title=?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, title);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
