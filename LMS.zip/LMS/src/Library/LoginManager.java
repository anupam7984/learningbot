package Library;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginManager {
    private DatabaseManager dbManager;

//    public LoginManager(DatabaseManager dbManager2) {
//		// TODO Auto-generated constructor stub
//	}
	public  LoginManager(DatabaseManager dbManager) {
        this.dbManager = dbManager;
    }
    public boolean authenticateUser(String username, String password) {
        try {
            Connection conn = dbManager.getConnection();
            String query = "SELECT * FROM users WHERE username=? AND password=?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace(); 
            System.out.println("user does not exists");
            return false;
        } 
        
    }
}
