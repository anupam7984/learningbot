package Library;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseManager {
    private static final String DB_URL = "jdbc:sqlserver://<192.168.138.30>:<1433>;databaseName=<'server'>";
    private static final String DB_USER = "username";
    private static final String DB_PASSWORD = "userpassword";
    private Connection conn;

    public DatabaseManager() {
        try {
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);    
            } 
        catch (SQLException e) {
            e.printStackTrace();   
            } 
        }
    public Connection getConnection() {
        return conn;
    }
    public void closeConnection() {
        try {
            if (conn != null) {
                conn.close();         
                }    
            } 
        catch (SQLException e) {
            e.printStackTrace();    
            }   
        }
}